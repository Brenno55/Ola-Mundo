package com.example.SimplestCRUDExample.controller;

import com.example.SimplestCRUDExample.model.Serie;
import com.example.SimplestCRUDExample.repo.SerieRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping
public class ListagemController {

    @Autowired
    SerieRepository serieRepository;

    @GetMapping("/listagem")
    public String listagem(Model model) {
        List<Serie> listadeserie = serieRepository.findAll();
        model.addAttribute("series", listadeserie);
        return "listagem"; // Este é o nome do seu arquivo HTML Thymeleaf
    }


    @GetMapping("/buscartodos")
    public ResponseEntity<List<Serie>> buscartodos() {
        try {
            List<Serie> listadeserie = new ArrayList<>();
            serieRepository.findAll().forEach(listadeserie::add);

            if (listadeserie.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(listadeserie, HttpStatus.OK);
        } catch(Exception ex) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/addserie")
    public ResponseEntity<Serie> addSerie(@ModelAttribute Serie serie) {
        try {
            Serie serieObj = serieRepository.save(serie);
            return new ResponseEntity<>(serieObj, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


}
