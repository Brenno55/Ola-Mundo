package com.example.brennolima.model;

import jakarta.persistence.*;
import lombok.*;


@Entity
@Table(name = "Series")
@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@ToString
public class Serie {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column
    private String titulo;

    @Column
    private String genero;

    @Column
    private String ano;
}
